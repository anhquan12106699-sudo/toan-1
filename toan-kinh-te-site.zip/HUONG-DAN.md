# Cấu trúc thư mục

- `index.html` — chỉ còn phần khung trang (các section: trang chủ, giới thiệu, tuyển sinh, tin tức, thư viện, CTĐT...).
- `css/` — giao diện, đánh số theo thứ tự nạp (số nhỏ nạp trước, file sau ghi đè file trước):
  - 01–10: giao diện chính (base, nav, hero, tuyển sinh, tin tức, bài viết, CTĐT...)
  - 11–23: các khối chỉnh sửa/ghi đè thêm sau này (polish, hero-v2, nav-flat...)
- `js/` — chức năng:
  - `01`–`08`: nav & hero, hiệu ứng, chuyển tab, bộ đọc Word, tin tức Supabase, bài viết PDF/Word, trang bài viết (nạp theo thứ tự số)
  - các file còn lại: supabase-client, tuyển sinh, CTĐT...
- `assets/` — ảnh (hero-1..5.webp, logo, favicon).

Lưu ý: KHÔNG đổi thứ tự các thẻ <link>/<script> trong index.html; muốn sửa gì thì mở đúng file theo tên.
Tên file toàn chữ thường, không dấu (GitHub Pages phân biệt hoa/thường).
